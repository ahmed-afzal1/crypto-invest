<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Auth;

class BanUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if (Auth::check() && Auth::user()->ban == 1) {
            Auth::guard('web')->logout();
            $request->session()->flash('error', "Your account has been suspended!");
            return redirect()->route('front.index');
        }
        return $next($request);
    }
}
