
     <div class="alert alert-success" style="display: none;" role="alert">
        <button type="button" class="close hide-close" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <p class="m-0"></p>
      </div>

